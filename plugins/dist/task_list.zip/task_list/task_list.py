# -*- coding: utf-8 -*-

import os
import re

from ninja_ide.core import plugin
from PyQt4.QtCore import QStringList
from PyQt4.QtCore import SIGNAL

from PyQt4.QtGui import QIcon
from PyQt4.QtGui import QWidget
from PyQt4.QtGui import QAbstractItemView
from PyQt4.QtGui import QHeaderView
from PyQt4.QtGui import QTreeWidget
from PyQt4.QtGui import QTreeWidgetItem
from PyQt4.QtGui import QVBoxLayout
from PyQt4.QtGui import QLabel


class TaskList(plugin.Plugin):
    def initialize(self):
        #get the services!
        self.main_s = self.locator.get_service('editor')
        self.explorer_s = self.locator.get_service('explorer')

        #explorer
        self._task_widget = TaskWidget(self.locator)
        self.explorer_s.add_tab(self._task_widget, "Tasks")

    def get_preferences_widget(self):
        return TaskPreferencesWidget()


class TaskPreferencesWidget(QWidget):

    def __init__(self):
        QWidget.__init__(self)
        vbox = QVBoxLayout(self)
        vbox.addWidget(QLabel("Configure your plugin!"))

    def save(self):
        print "salvando preferencias!!!"


class TaskWidget(QTreeWidget):

    TASK_IMAGE = os.path.join(os.path.dirname(__file__), 'task.png')
    TODO_REG = re.compile("#(\\s)*TODO(\\s)*\\:(\\s)*.")
    FIXME_REG = re.compile("#(\\s)*FIXME(\\s)*\\:(\\s)*.")
    OPTIMIZE_REG = re.compile("#(\\s)*OPTIMIZE(\\s)*\\:(\\s)*.")

    def __init__(self, locator):
        QTreeWidget.__init__(self)
        self.locator = locator
        self._explorer_s = self.locator.get_service('explorer')
        self._main_s = self.locator.get_service('editor')
        #on current tab changed
        self._main_s.currentTabChanged.connect(self.refresh_tasks)

        self.header().setHidden(True)
        self.setSelectionMode(self.SingleSelection)
        self.setAnimated(True)
        self.header().setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.header().setResizeMode(0, QHeaderView.ResizeToContents)
        self.header().setStretchLastSection(False)

        self.connect(self, SIGNAL("itemClicked(QTreeWidgetItem *, int)"),
            self._go_to_definition)

    def refresh_tasks(self):
        editorWidget = self._main_s.get_editor()
        if editorWidget:
            source = self._main_s.get_text()
            self._parse_tasks(source)

    def _go_to_definition(self, item):
        #the root doesnt go to anywhere
        if item.parent() is not None:
            self._main_s.jump_to_line(item.lineno)

    def _parse_tasks(self, source_code):
        self.clear()
        #create roots
        todo_root = QTreeWidgetItem(self, QStringList('TODO'))
        fixme_root = QTreeWidgetItem(self, QStringList('FIXME'))
        optimize_root = QTreeWidgetItem(self, QStringList('OPTIMIZE'))

        lines = source_code.split("\n")
        lineno = 0
        for line in lines:
            #apply the regular expressions
            todo_match = self.TODO_REG.search(line)
            fixme_match = self.FIXME_REG.search(line)
            optimize_match = self.OPTIMIZE_REG.search(line)
            if todo_match:
                content = line[todo_match.end() - 1:]
                item = TaskItem(todo_root, QStringList(content), lineno)
                item.setIcon(0, QIcon(self.TASK_IMAGE))
            elif fixme_match:
                content = line[fixme_match.end() - 1:]
                item = TaskItem(fixme_root, QStringList(content), lineno)
                item.setIcon(0, QIcon(self.TASK_IMAGE))
            elif optimize_match:
                content = line[optimize_match.end() - 1:]
                item = TaskItem(optimize_root, QStringList(content), lineno)
                item.setIcon(0, QIcon(self.TASK_IMAGE))

            lineno += 1
        self.expandAll()


class TaskItem(QTreeWidgetItem):

    def __init__(self, parent, content, lineno):
        QTreeWidgetItem.__init__(self, parent, content)
        self.lineno = lineno
