import os

def main():
    #TODO: agregar soporte de unicode
    a = 1
    #OPTIMIZE: anda lento!


#FIXME: problema de interfaces
def f():

    #FIXME: que pasa aca?
    return True

f(1) #OPTIMIZE: pierde performance esta linea con mas de 10!
